#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
	ifstream inFS;
	string userWord;
	int wordFreq = 0;
	string currWord;
	

	inFS.open("frequency.dat");

	cout << "Enter a word: ";
	cin >> userWord;

	// Identify when a word matches the userWord 
	// and increase wordFreq
	while (!inFS.eof()) {
		inFS >> currWord;
		if (!inFS.fail()) {
			if (currWord == userWord) {
				++wordFreq;
			}
		}

	}

	cout << wordFreq << endl;
	system("PAUSE");
	cout << userWord << " "<< wordFreq << endl;
	system("PAUSE");
	int x;
	x = wordFreq;
	cout << userWord << " ";
	for (int i = 0; i < x; i++) {
		cout <<  "*";
	}
		// Done with file, so close it
		inFS.close();

		system("PAUSE");
		return 0;
	}

